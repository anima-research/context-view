import { copyFileSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { basename, dirname, join, resolve } from "node:path";

/** The release is switched, and something after the switch isn't finished: the message says each part. `main` exits 3 for it. */
export class PromotedUnfinished extends Error {}

export type Run = (args: string[], cwd: string, env?: Record<string, string | undefined>) => Promise<string>;

/** What a component's own steps are given. `target` is the installed package directory, `~/.local/lib/<packageName>` under `home`. */
export type Context = {
  home: string;
  source: string;
  revision: string;
  rehearsal: boolean;
  target: string;
  run: Run;
};

/** `prepare` also gets the stage, the release as it will be installed, and `install`, which runs `bun install --frozen-lockfile --backend=copyfile` there with the given flags. */
export type PrepareContext = Context & { stage: string; install: (...flags: string[]) => Promise<string> };

export type Spec = {
  /** The component's name for review-workflow's release gate: `release-gate install COMPONENT REV`. */
  component: string;
  /** The install directory's name, `~/.local/lib/<packageName>`, and the promote lock's. */
  packageName: string;
  /** The checkout promoted when `Options.source` names none. */
  source: string;
  /** Each command `~/.local/bin` gets, and the file of the release its launcher runs, as `interpreter` says. Each must answer `--help` from the stage. */
  commands: Record<string, string>;
  /** How each command's file runs, in its launcher and its `--help` check: with Bun (the default), or by its own first line (`shebang`), for files that run themselves, such as bash scripts, committed executable. */
  interpreter?: "bun" | "shebang";
  /** The answer's `adoption`: what a reader does, if anything, for the release to be what runs. */
  adoption: string;
  /** Files of the release put in place with the launchers: `from` in the release, `to` under the home and outside the install directory. */
  place?: readonly { from: string; to: string }[];
  /** Runs in the stage after its production install, before the `--help` check; a throw promotes nothing, and what it returns joins the answer. */
  prepare?: (context: PrepareContext) => Promise<Record<string, unknown> | void>;
  /** Runs after the marker is recorded (or found unrecordable); a throw is reported with the switch, and what it returns joins the answer. */
  afterSwitch?: (context: Context) => Promise<Record<string, unknown> | void>;
};

export type Options = { home?: string; account?: string; source?: string };

export type Answer = {
  gate: string;
  marker: string | null;
  package: string;
  revision: string;
  installed: string;
  commands: string[];
  adoption: string;
  [field: string]: unknown;
};

export const quote = (s: string) => "'" + s.replaceAll("'", "'\\''") + "'";

async function spawn(args: string[], cwd: string, env: Record<string, string | undefined> = process.env) {
  const child = Bun.spawn(args, { cwd, env, stdin: "ignore", stdout: "pipe", stderr: "pipe" });
  const [out, err, code] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
  return { code, out: out.trim(), err: err.trim() };
}

const run: Run = async (args, cwd, env) => {
  const { code, out, err } = await spawn(args, cwd, env);
  if (code !== 0) throw Error(`${args.join(" ")} failed (${code}):\n${out}${out && err ? "\n" : ""}${err}`);
  return out;
};

function canonical(path: string): string {
  try {
    return realpathSync(path);
  } catch {
    return resolve(path);
  }
}

function present(path: string): boolean {
  try {
    lstatSync(path);
    return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

function trimmedText(path: string): string | null {
  try {
    return readFileSync(path, "utf8").trim();
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}

/** Under Bun, os.homedir() and os.userInfo().homedir both report the HOME the process started with, when it's set, not the password database's. */
export function accountHome(): string {
  const entry = Bun.spawnSync(["getent", "passwd", String(process.getuid?.() ?? "")], { stdout: "pipe", stderr: "ignore" });
  const home = entry.exitCode === 0 ? entry.stdout.toString().trim().split(":")[5] : undefined;
  if (!home) throw Error("The account's home could not be read from the password database (getent passwd); nothing was promoted");
  return home;
}

/** A rehearsal is a promote into another home than the account's own, compared as the filesystem resolves them. */
export const isRehearsal = (home: string, account: string) => canonical(home) !== canonical(account);

/** Where the marker is recorded: `ASTRA_PROMOTE_REPOSITORY`, resolved against the source, or the source itself unless this is a rehearsal. */
export function markerRepository(source: string, rehearsal: boolean, env: NodeJS.ProcessEnv = process.env): string | null {
  return env.ASTRA_PROMOTE_REPOSITORY ? resolve(source, env.ASTRA_PROMOTE_REPOSITORY) : rehearsal ? null : source;
}

function markerPath(source: string): string {
  const given = process.env.ASTRA_PROMOTE_MARKER ?? "astra-promote-marker";
  // Bun.which reads the PATH the process started with unless it's given one (Bun 1.4.4).
  const path = Bun.which(given.includes("/") ? resolve(source, given) : given, { PATH: process.env.PATH ?? "" });
  if (path) return path;
  if (process.env.ASTRA_PROMOTE_MARKER) throw Error(`ASTRA_PROMOTE_MARKER names ${given}, which isn't an executable file; nothing was promoted`);
  throw Error(`astra-promote-marker isn't on PATH (git-hooks' bun run promote installs it); nothing was promoted`);
}

/**
 * Asks the live release gate, `~/.local/bin/release-gate install COMPONENT REVISION`, with HOME set to `home`, unless nothing in
 * `live` is there (a host's first install). Returns the gate's answer, or throws with its words and its exit or signal (the gate's
 * own refusal is exit 3), or, when the launcher can't be started at all, with why.
 */
export function askGate(o: { home: string; component: string; revision: string; live: readonly string[] }): string {
  if (!o.live.some(present)) return "a first install, with nothing live to compare against";
  const launcher = join(o.home, ".local/bin/release-gate");
  const gate = (() => {
    try {
      return Bun.spawnSync([launcher, "install", o.component, o.revision], {
        cwd: o.home,
        env: { ...process.env, HOME: o.home },
        stdout: "pipe",
        stderr: "pipe",
      });
    } catch (error) {
      // Bun 1.4.4 throws here, rather than returning an exit, when the launcher is missing (ENOENT) or not executable (EACCES).
      throw Error(
        `The release gate couldn't be run for ${o.component} release ${o.revision} (${(error as Error).message}); ` +
          `review-workflow's promote installs ${launcher}. Nothing was promoted.`,
      );
    }
  })();
  if (gate.exitCode !== 0 || gate.signalCode)
    throw Error(
      `${(gate.stderr.toString() || gate.stdout.toString()).trim()}\n` +
        `The release gate didn't pass ${o.component} release ${o.revision} ` +
        `(release-gate ${gate.signalCode ? `ended on ${gate.signalCode}` : `exited ${gate.exitCode}`}); nothing was promoted.`,
    );
  return gate.stdout.toString().trim();
}

/**
 * The switch this promote of `revision` makes, for its marker. A switch, a promote of another revision than the installed one or
 * where none is installed, names the revision it replaces (if any) and takes an event of its own. A run again of the installed revision is that release's own switch again: the
 * revision it replaced and its event, from its `.previous-revision` and `.promote-event`, or neither for a release installed before
 * those files existed.
 */
export type Predecessor = { previous: string | null; event: string | null };
export function predecessor(target: string, revision: string): Predecessor {
  const installed = trimmedText(join(target, ".installed-revision"));
  if (installed !== revision) return { previous: installed || null, event: `promote-${crypto.randomUUID()}` };
  return { previous: trimmedText(join(target, ".previous-revision")) || null, event: trimmedText(join(target, ".promote-event")) || null };
}

/** Writes the release's own record into its stage before the switch: `.installed-revision`, and its switch's `.previous-revision` and `.promote-event`. */
export function stamp(stage: string, revision: string, before: Predecessor) {
  writeFileSync(join(stage, ".installed-revision"), revision + "\n");
  if (before.previous) writeFileSync(join(stage, ".previous-revision"), before.previous + "\n");
  if (before.event) writeFileSync(join(stage, ".promote-event"), before.event + "\n");
}

/**
 * Records the promote on `repository`'s main with `marker`, naming the revision it replaced and its switch's event, so a run again,
 * and the command printed when the marker fails, each replay that switch and the marker answers "already" once it's recorded.
 */
export async function recordMarker(o: {
  marker: string;
  repository: string;
  revision: string;
  before: Predecessor;
  cwd: string;
}): Promise<{ recorded: string } | { unfinished: string }> {
  const record = ["record", o.revision, "--repo", o.repository];
  if (o.before.previous) record.push("--previous", o.before.previous);
  if (o.before.event) record.push("--event", o.before.event);
  let marked: { code: number | null; out: string; err: string };
  try {
    marked = await spawn([o.marker, ...record], o.cwd);
  } catch (error) {
    marked = { code: null, out: "", err: error instanceof Error ? error.message : String(error) };
  }
  if (marked.code === 0) return { recorded: marked.out };
  const words = [marked.err, marked.out].filter(Boolean).join("\n");
  return {
    unfinished:
      `its promote marker may not be recorded (${marked.code === null ? "the marker couldn't be started" : `the marker exited ${marked.code}`}). ` +
      `Once whatever stopped it is dealt with, record it with the command below, which answers "already" if it was recorded after all:\n  ${[o.marker, ...record].map(quote).join(" ")}` +
      (words ? `\n  The marker said: ${words.replaceAll("\n", "\n  ")}` : ""),
  };
}

export function unfinished(revision: string, recorded: boolean, parts: readonly string[]): PromotedUnfinished {
  return new PromotedUnfinished(
    `Promoted ${revision}${recorded ? " and recorded its promote marker" : ""}, but not everything is finished:` + parts.map((part) => `\n- ${part}`).join(""),
  );
}

// Bun's cache is under BUN_INSTALL, which defaults to HOME's .bun, so a rehearsal's scratch home would start with an empty one.
function installEnvironment(rehearsal: boolean, account: string) {
  if (!rehearsal || process.env.BUN_INSTALL_CACHE_DIR) return process.env;
  const bun = process.env.BUN_INSTALL || join(account, ".bun");
  return { ...process.env, BUN_INSTALL_CACHE_DIR: join(bun, "install/cache") };
}

/** Exchanges `staged` with `target` in one renameat2, or renames `staged` into place when nothing is at `target`. */
export async function replaceDirectory(staged: string, target: string) {
  if (!present(target)) {
    renameSync(staged, target);
    return;
  }
  const exchange = await spawn(
    [
      "python3",
      "-c",
      `import ctypes, os, sys
libc = ctypes.CDLL(None, use_errno=True)
AT_FDCWD, RENAME_EXCHANGE = -100, 2
if libc.renameat2(AT_FDCWD, os.fsencode(sys.argv[1]), AT_FDCWD, os.fsencode(sys.argv[2]), RENAME_EXCHANGE):
    raise OSError(ctypes.get_errno(), os.strerror(ctypes.get_errno()))
`,
      staged,
      target,
    ],
    dirname(target),
  );
  if (exchange.code !== 0)
    throw Error(`The switch of ${target} to the stage at ${staged} failed (python3's renameat2 exited ${exchange.code}${exchange.err ? `: ${exchange.err.split("\n").at(-1)}` : ""}), so nothing was switched.`);
}

/** Installs the committed revision of `spec`'s source under `~/.local/lib/<packageName>`, with its launchers and placed files, and records it. */
export async function promote(spec: Spec, options: Options = {}): Promise<Answer> {
  const home = options.home ?? homedir();
  const source = options.source ?? spec.source;
  const account = options.account ?? accountHome();
  const lib = join(home, ".local/lib"),
    bin = join(home, ".local/bin");
  const target = join(lib, spec.packageName);
  if (await run(["git", "status", "--porcelain", "--untracked-files=all"], source)) throw Error("Commit this package's intended changes before promotion");
  const revision = await run(["git", "rev-parse", "HEAD"], source);
  const rehearsal = isRehearsal(home, account);
  const repository = markerRepository(source, rehearsal);
  const marker = repository ? markerPath(source) : null;
  const before = predecessor(target, revision);
  const launchers = Object.keys(spec.commands).map((name) => join(bin, name));
  const gate = rehearsal
    ? "a rehearsal, from another home than the account's: no gate is asked"
    : askGate({ home, component: spec.component, revision, live: [target, ...launchers] });
  mkdirSync(lib, { recursive: true });
  const stage = mkdtempSync(join(lib, `.${spec.packageName}-install-`));
  const temporaries = new Map<string, string>();
  try {
    const archive = join(stage, "source.tar");
    await run(["git", "archive", "--format=tar", "-o", archive, revision], source);
    await run(["tar", "-xf", archive, "-C", stage], source);
    rmSync(archive);
    const environment = installEnvironment(rehearsal, account);
    const install = (...flags: string[]) => run([process.execPath, "install", "--frozen-lockfile", "--backend=copyfile", ...flags], stage, environment);
    await install("--production");
    const context: Context = { home, source, revision, rehearsal, target, run };
    const prepared = (await spec.prepare?.({ ...context, stage, install })) ?? {};
    const shebang = spec.interpreter === "shebang";
    for (const entry of Object.values(spec.commands))
      await run([...(shebang ? [] : [process.execPath, "run"]), join(stage, entry), "--help"], stage, { ...process.env, HOME: home });
    stamp(stage, revision, before);

    const files: { to: string; write: (temporary: string) => void }[] = [
      ...Object.entries(spec.commands).map(([name, entry]) => ({
        to: join(bin, name),
        write: (temporary: string) =>
          writeFileSync(temporary, `#!/bin/sh\nset -eu\nexec ${shebang ? "" : `${quote(process.execPath)} `}${quote(join(target, entry))} "$@"\n`, { mode: 0o755 }),
      })),
      ...(spec.place ?? []).map(({ from, to }) => ({ to: join(home, to), write: (temporary: string) => copyFileSync(join(stage, from), temporary) })),
    ];
    for (const file of files) {
      mkdirSync(dirname(file.to), { recursive: true });
      const temporary = join(dirname(file.to), `.${basename(file.to)}-${crypto.randomUUID()}`);
      temporaries.set(temporary, file.to);
      file.write(temporary);
    }
    await replaceDirectory(stage, target);

    const parts: string[] = [];
    let unplaced = "";
    for (const [temporary, to] of temporaries)
      try {
        renameSync(temporary, to);
      } catch (error) {
        unplaced += `\n  ${to}: ${(error as Error).message}`;
      }
    if (unplaced)
      parts.push(
        `these files weren't put in place, so each still holds what was there before, and what watches a launcher among them won't restart onto this release by itself:${unplaced}\n  Clear what stopped each, then run the promote again, which puts them in place.`,
      );
    let recorded: string | null = null;
    if (repository && marker) {
      const marked = await recordMarker({ marker, repository, revision, before, cwd: source });
      if ("recorded" in marked) recorded = marked.recorded;
      else parts.push(marked.unfinished);
    }
    let after: Record<string, unknown> = {};
    try {
      after = (await spec.afterSwitch?.(context)) ?? {};
    } catch (error) {
      parts.push(error instanceof Error ? error.message : String(error));
    }
    if (parts.length) throw unfinished(revision, recorded !== null, parts);
    return {
      gate,
      marker: recorded,
      package: spec.packageName,
      revision,
      installed: target,
      commands: Object.keys(spec.commands),
      ...prepared,
      ...after,
      adoption: spec.adoption,
    };
  } finally {
    removeLeftovers([stage, ...temporaries.keys()]);
  }
}

/** Removes each leftover, a directory with what it holds, and names on stderr each it couldn't remove, so a failed removal changes neither the promote's answer nor its error. */
export function removeLeftovers(leftovers: Iterable<string>) {
  for (const leftover of leftovers)
    try {
      rmSync(leftover, { recursive: true, force: true });
    } catch (error) {
      console.error(`Left behind ${leftover}, to remove by hand: ${(error as Error).message}`);
    }
}

/**
 * A promote script's entry: holds `~/.local/lib/.<packageName>.promote.lock` (re-executing the script under `flock`), prints the
 * answer as JSON, and exits 1 when nothing was switched or 3 when `PromotedUnfinished` says what's left.
 */
export async function main(packageName: string, promote: () => Promise<unknown>) {
  const lock = join(homedir(), `.local/lib/.${packageName}.promote.lock`);
  if (process.env.ASTRA_PROMOTE_LOCK !== lock) {
    mkdirSync(dirname(lock), { recursive: true });
    const held = Bun.spawnSync(["flock", lock, process.execPath, ...process.argv.slice(1)], {
      env: { ...process.env, ASTRA_PROMOTE_LOCK: lock },
      stdio: ["inherit", "inherit", "inherit"],
    });
    process.exit(held.exitCode ?? 1);
  }
  try {
    console.log(JSON.stringify(await promote(), null, 2));
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = error instanceof PromotedUnfinished ? 3 : 1;
  }
}
