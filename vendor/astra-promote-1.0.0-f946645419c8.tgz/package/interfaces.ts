import {
  accountHome as accountHomeImpl,
  askGate as askGateImpl,
  isRehearsal as isRehearsalImpl,
  main as promoteMainImpl,
  markerRepository as markerRepositoryImpl,
  predecessor as predecessorImpl,
  PromotedUnfinished as PromotedUnfinishedImpl,
  quote as quoteImpl,
  recordMarker as recordMarkerImpl,
  removeLeftovers as removeLeftoversImpl,
  replaceDirectory as replaceDirectoryImpl,
  stamp as stampImpl,
  unfinished as unfinishedImpl,
  promote as promoteImpl,
} from "./promote";

/** @public */
export type Run = (args: string[], cwd: string, env?: Record<string, string | undefined>) => Promise<string>;

/** @public */
export type Context = {
  home: string;
  source: string;
  revision: string;
  rehearsal: boolean;
  target: string;
  run: Run;
};

/** @public */
export type PrepareContext = Context & { stage: string; install: (...flags: string[]) => Promise<string> };

/** @public */
export type Spec = {
  /** The component's name for review-workflow's release gate: `release-gate install COMPONENT REV`. */
  component: string;
  packageName: string;
  source: string;
  commands: Record<string, string>;
  interpreter?: "bun" | "shebang";
  adoption: string;
  place?: readonly { from: string; to: string }[];
  prepare?: (context: PrepareContext) => Promise<Record<string, unknown> | void>;
  afterSwitch?: (context: Context) => Promise<Record<string, unknown> | void>;
  releases?: { openRuns: readonly string[] };
};

/** @public */
export type Options = { home?: string; account?: string; source?: string };

/** @public */
export type Answer = {
  gate: string;
  marker: string | null;
  package: string;
  revision: string;
  installed: string;
  commands: string[];
  adoption: string;
  [field: string]: unknown;
};

/** @public */
export type Predecessor = { previous: string | null; event: string | null };

/** @public */
export type Promote = (spec: Spec, options?: Options) => Promise<Answer>;
/** @public */
export const promote: Promote = promoteImpl;
/** @public */
export interface PromotedUnfinished extends Error {}
/** @public */
export const PromotedUnfinished: typeof PromotedUnfinishedImpl = PromotedUnfinishedImpl;
/** The account's home from the password database, which Bun's homedir() doesn't give when HOME is set.
 * @public */
export type AccountHome = () => string;
/** @public */
export const accountHome: AccountHome = accountHomeImpl;
/** @public */
export type IsRehearsal = (home: string, account: string) => boolean;
/** @public */
export const isRehearsal: IsRehearsal = isRehearsalImpl;
/** @public */
export type MarkerRepository = (source: string, rehearsal: boolean, env?: NodeJS.ProcessEnv) => string | null;
/** @public */
export const markerRepository: MarkerRepository = markerRepositoryImpl;
/** @public */
export type AskGate = (o: { home: string; component: string; revision: string; live: readonly string[] }) => string;
/** @public */
export const askGate: AskGate = askGateImpl;
/** @public */
export type PredecessorOf = (target: string, revision: string) => Predecessor;
/** @public */
export const predecessor: PredecessorOf = predecessorImpl;
/** @public */
export type Stamp = (stage: string, revision: string, before: Predecessor) => void;
/** @public */
export const stamp: Stamp = stampImpl;
/** @public */
export type RecordMarker = (o: { marker: string; repository: string; revision: string; before: Predecessor; cwd: string }) => Promise<{ recorded: string } | { unfinished: string }>;
/** @public */
export const recordMarker: RecordMarker = recordMarkerImpl;
/** @public */
export type Unfinished = (revision: string, recorded: boolean, parts: readonly string[]) => PromotedUnfinished;
/** @public */
export const unfinished: Unfinished = unfinishedImpl;
/** @public */
export type ReplaceDirectory = (staged: string, target: string) => Promise<void>;
/** @public */
export const replaceDirectory: ReplaceDirectory = replaceDirectoryImpl;
/** @public */
export type RemoveLeftovers = (leftovers: Iterable<string>) => void;
/** @public */
export const removeLeftovers: RemoveLeftovers = removeLeftoversImpl;
/** @public */
export type Quote = (s: string) => string;
/** @public */
export const quote: Quote = quoteImpl;
/** @public */
export type PromoteMain = (packageName: string, promote: () => Promise<unknown>) => Promise<void>;
/** @public */
export const main: PromoteMain = promoteMainImpl;
