import { copyFileSync, lstatSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, readlinkSync, realpathSync, renameSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { basename, dirname, join, resolve } from "node:path";

import type { Answer, Context, Options, PrepareContext, Predecessor, Run, Spec } from "./interfaces";

export class PromotedUnfinished extends Error {}

export const quote = (s: string) => "'" + s.replaceAll("'", "'\\''") + "'";

const BUN_ALONE = ["--no-env-file", "--config=/dev/null"] as const;

async function spawn(args: string[], cwd: string, env: Record<string, string | undefined> = process.env) {
  const child = Bun.spawn(args, { cwd, env, stdin: "ignore", stdout: "pipe", stderr: "pipe" });
  const [out, err, code] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
  return { code, out: out.trim(), err: err.trim() };
}

const run: Run = async (args, cwd, env) => {
  const { code, out, err } = await spawn(args, cwd, env);
  if (code !== 0) throw Error(`${args.join(" ")} failed (${code}):\n${out}${out && err ? "\n" : ""}${err}`);
  return out;
};

function canonical(path: string): string {
  try {
    return realpathSync(path);
  } catch {
    return resolve(path);
  }
}

function present(path: string): boolean {
  try {
    lstatSync(path);
    return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
}

function trimmedText(path: string): string | null {
  try {
    return readFileSync(path, "utf8").trim();
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw error;
  }
}

/** Under Bun, os.homedir() and os.userInfo().homedir both report the HOME the process started with, when it's set, not the password database's. */
export function accountHome(): string {
  const entry = Bun.spawnSync(["getent", "passwd", String(process.getuid?.() ?? "")], { stdout: "pipe", stderr: "ignore" });
  const home = entry.exitCode === 0 ? entry.stdout.toString().trim().split(":")[5] : undefined;
  if (!home) throw Error("The account's home could not be read from the password database (getent passwd); nothing was promoted");
  return home;
}

export const isRehearsal = (home: string, account: string) => canonical(home) !== canonical(account);

export function markerRepository(source: string, rehearsal: boolean, env: NodeJS.ProcessEnv = process.env): string | null {
  return env.ASTRA_PROMOTE_REPOSITORY ? resolve(source, env.ASTRA_PROMOTE_REPOSITORY) : rehearsal ? null : source;
}

function markerPath(source: string): string {
  const given = process.env.ASTRA_PROMOTE_MARKER ?? "astra-promote-marker";
  // Bun.which reads the PATH the process started with unless it's given one (Bun 1.4.4).
  const path = Bun.which(given.includes("/") ? resolve(source, given) : given, { PATH: process.env.PATH ?? "" });
  if (path) return path;
  if (process.env.ASTRA_PROMOTE_MARKER) throw Error(`ASTRA_PROMOTE_MARKER names ${given}, which isn't an executable file; nothing was promoted`);
  throw Error(`astra-promote-marker isn't on PATH (git-hooks' bun run promote installs it); nothing was promoted`);
}

/**
 * Asks the live release gate, `~/.local/bin/release-gate install COMPONENT REVISION`, with HOME set to `home`, unless nothing in
 * `live` is there (a host's first install). Returns the gate's answer, or throws with its words and its exit or signal (the gate's
 * own refusal is exit 3), or, when the launcher can't be started at all, with why.
 */
export function askGate(o: { home: string; component: string; revision: string; live: readonly string[] }): string {
  if (!o.live.some(present)) return "a first install, with nothing live to compare against";
  const launcher = join(o.home, ".local/bin/release-gate");
  const gate = (() => {
    try {
      return Bun.spawnSync([launcher, "install", o.component, o.revision], {
        cwd: o.home,
        env: { ...process.env, HOME: o.home },
        stdout: "pipe",
        stderr: "pipe",
      });
    } catch (error) {
      // Bun 1.4.4 throws here, rather than returning an exit, when the launcher is missing (ENOENT) or not executable (EACCES).
      throw Error(
        `The release gate couldn't be run for ${o.component} release ${o.revision} (${(error as Error).message}); ` +
          `review-workflow's promote installs ${launcher}. Nothing was promoted.`,
      );
    }
  })();
  if (gate.exitCode !== 0 || gate.signalCode)
    throw Error(
      `${(gate.stderr.toString() || gate.stdout.toString()).trim()}\n` +
        `The release gate didn't pass ${o.component} release ${o.revision} ` +
        `(release-gate ${gate.signalCode ? `ended on ${gate.signalCode}` : `exited ${gate.exitCode}`}); nothing was promoted.`,
    );
  return gate.stdout.toString().trim();
}

/**
 * The switch this promote of `revision` makes, for its marker. A switch, a promote of another revision than the installed one or
 * where none is installed, names the revision it replaces (if any) and takes an event of its own. A run again of the installed revision is that release's own switch again: the
 * revision it replaced and its event, from its `.previous-revision` and `.promote-event`, or neither for a release installed before
 * those files existed.
 */
export function predecessor(target: string, revision: string): Predecessor {
  const installed = trimmedText(join(target, ".installed-revision"));
  if (installed !== revision) return { previous: installed || null, event: `promote-${crypto.randomUUID()}` };
  return { previous: trimmedText(join(target, ".previous-revision")) || null, event: trimmedText(join(target, ".promote-event")) || null };
}

export function stamp(stage: string, revision: string, before: Predecessor) {
  writeFileSync(join(stage, ".installed-revision"), revision + "\n");
  if (before.previous) writeFileSync(join(stage, ".previous-revision"), before.previous + "\n");
  if (before.event) writeFileSync(join(stage, ".promote-event"), before.event + "\n");
}

/**
 * Records the promote on `repository`'s main with `marker`, naming the revision it replaced and its switch's event, so a run again,
 * and the command printed when the marker fails, each replay that switch and the marker answers "already" once it's recorded.
 */
export async function recordMarker(o: {
  marker: string;
  repository: string;
  revision: string;
  before: Predecessor;
  cwd: string;
}): Promise<{ recorded: string } | { unfinished: string }> {
  const record = ["record", o.revision, "--repo", o.repository];
  if (o.before.previous) record.push("--previous", o.before.previous);
  if (o.before.event) record.push("--event", o.before.event);
  let marked: { code: number | null; out: string; err: string };
  try {
    marked = await spawn([o.marker, ...record], o.cwd);
  } catch (error) {
    marked = { code: null, out: "", err: error instanceof Error ? error.message : String(error) };
  }
  if (marked.code === 0) return { recorded: marked.out };
  const words = [marked.err, marked.out].filter(Boolean).join("\n");
  return {
    unfinished:
      `its promote marker may not be recorded (${marked.code === null ? "the marker couldn't be started" : `the marker exited ${marked.code}`}). ` +
      `Once whatever stopped it is dealt with, record it with the command below, which answers "already" if it was recorded after all:\n  ${[o.marker, ...record].map(quote).join(" ")}` +
      (words ? `\n  The marker said: ${words.replaceAll("\n", "\n  ")}` : ""),
  };
}

export function unfinished(revision: string, recorded: boolean, parts: readonly string[]): PromotedUnfinished {
  return new PromotedUnfinished(
    `Promoted ${revision}${recorded ? " and recorded its promote marker" : ""}, but not everything is finished:` + parts.map((part) => `\n- ${part}`).join(""),
  );
}

// Bun's cache is under BUN_INSTALL, which defaults to HOME's .bun, so a rehearsal's scratch home would start with an empty one.
function installEnvironment(rehearsal: boolean, account: string) {
  if (!rehearsal || process.env.BUN_INSTALL_CACHE_DIR) return process.env;
  const bun = process.env.BUN_INSTALL || join(account, ".bun");
  return { ...process.env, BUN_INSTALL_CACHE_DIR: join(bun, "install/cache") };
}

export async function replaceDirectory(staged: string, target: string) {
  if (!present(target)) {
    renameSync(staged, target);
    return;
  }
  const exchange = await spawn(
    [
      "python3",
      "-c",
      `import ctypes, os, sys
libc = ctypes.CDLL(None, use_errno=True)
AT_FDCWD, RENAME_EXCHANGE = -100, 2
if libc.renameat2(AT_FDCWD, os.fsencode(sys.argv[1]), AT_FDCWD, os.fsencode(sys.argv[2]), RENAME_EXCHANGE):
    raise OSError(ctypes.get_errno(), os.strerror(ctypes.get_errno()))
`,
      staged,
      target,
    ],
    dirname(target),
  );
  if (exchange.code !== 0)
    throw Error(`The switch of ${target} to the stage at ${staged} failed (python3's renameat2 exited ${exchange.code}${exchange.err ? `: ${exchange.err.split("\n").at(-1)}` : ""}), so nothing was switched.`);
}

const isLink = (path: string) => present(path) && lstatSync(path).isSymbolicLink();

function listed(directory: string): string {
  try {
    return readdirSync(directory).sort().join(", ") || "nothing";
  } catch (error) {
    return `what can't be listed (${(error as Error).message})`;
  }
}

export function releasesLayout(root: string, bin: string): "none" | "releases" {
  if (!present(root)) return "none";
  const current = join(root, "current");
  if (isLink(current)) {
    let named: string | null = null,
      why = "";
    try {
      named = realpathSync(current);
    } catch (error) {
      why = ` (${(error as Error).message})`;
    }
    if (named && lstatSync(named).isDirectory()) return "releases";
    throw Error(
      `${current} names ${readlinkSync(current)}, which isn't a directory${why}, so which release serves can't be told, and nothing was promoted. ` +
        `releases/ holds ${listed(join(root, "releases"))}: point current at the one that serves, or, if none does, remove ${root} with the component's launchers in ${bin}, so the next promote installs afresh, as a host's first, which asks no gate.`,
    );
  }
  throw Error(
    `${root} is there without a current link, so it isn't an install of releases, and nothing was promoted. It holds ${listed(root)}. ` +
      `If it's this component's release installed in place, from before the component took releases, move it aside with the component's launchers in ${bin}: with none of them in place, this promote installs as a host's first, which asks no gate, so have the release reviewed against what that install ran before promoting it. ` +
      `If it's left from an install that stopped partway, remove it once nothing in it is wanted.`,
  );
}

function writeWhole(path: string, text: string) {
  const temporary = join(dirname(path), `.${basename(path)}-${crypto.randomUUID()}`);
  try {
    writeFileSync(temporary, text);
    renameSync(temporary, path);
  } finally {
    rmSync(temporary, { force: true });
  }
}

/** The most open runs one page of `astra-workflows integration`'s listing gives, its largest (workflow-house's service.ts). */
export const OPEN_RUNS_PAGE = 500;

export async function openRunsSince(names: readonly string[]): Promise<number | null | string> {
  const shown = "astra-workflows integration (list)";
  const path = Bun.which("astra-workflows", { PATH: process.env.PATH ?? "" });
  if (!path) return "astra-workflows isn't on PATH, so the open runs can't be listed";
  let listing: { code: number; out: string; err: string };
  try {
    const child = Bun.spawn([path, "integration"], {
      stdin: new Blob([JSON.stringify({ operation: "list", limit: OPEN_RUNS_PAGE })]),
      stdout: "pipe",
      stderr: "pipe",
    });
    const [out, err, code] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
    listing = { code, out, err };
  } catch (error) {
    return `${shown} couldn't be started (${(error as Error).message})`;
  }
  if (listing.code !== 0) return `${shown} exited ${listing.code} (${(listing.err || listing.out).trim().slice(0, 300) || "nothing said"})`;
  let runs: { name: unknown; createdAt: unknown }[];
  try {
    runs = (JSON.parse(listing.out) as { runs: { run: { name: unknown; createdAt: unknown } }[] }).runs.map((entry) => entry.run);
    if (runs.some((run) => typeof run.name !== "string" || typeof run.createdAt !== "number")) throw Error();
  } catch {
    return `${shown} answered with something other than its runs: ${JSON.stringify(listing.out.slice(0, 200))}`;
  }
  if (runs.length >= OPEN_RUNS_PAGE) return `${shown} gave a full page of ${OPEN_RUNS_PAGE} open runs, so it may not have given them all`;
  const times = runs.filter((run) => names.includes(run.name as string)).map((run) => run.createdAt as number);
  return times.length ? Math.min(...times) : null;
}

/** The names astra-release-prune counts as releases (its REVISION). It refuses a whole run given a `--keep` that, once resolved, lies in no release, and this file is exported alone, so it can't import that. */
const RELEASE_NAME = /^[0-9a-f]{7,64}$/;

function writeSwitch(release: string, before: Predecessor) {
  for (const [file, value] of [
    [".previous-revision", before.previous],
    [".promote-event", before.event],
  ] as const)
    if (value) writeWhole(join(release, file), value + "\n");
    else rmSync(join(release, file), { force: true });
}

function replacedAt(release: string): number | null {
  try {
    const text = readFileSync(join(release, ".replaced"), "utf8").trim();
    return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(text) ? Date.parse(text) : null;
  } catch {
    return null;
  }
}

async function pruneReleases(root: string, openRuns: readonly string[]): Promise<{ done: boolean; said: string }> {
  const later = "a later promote prunes again";
  const since = openRuns.length ? await openRunsSince(openRuns) : null;
  if (typeof since === "string") return { done: false, said: `${since}, so no release was pruned, since an open run may still be using one; ${later}` };
  const releases = join(root, "releases");
  let args: string[];
  try {
    const named = readdirSync(releases).filter((name) => RELEASE_NAME.test(name));
    const keep = since === null ? [] : named.filter((name) => (replacedAt(join(releases, name)) ?? Infinity) >= since).map((name) => join(releases, name));
    const firstOnly = named.length <= 1 && !present(join(root, "previous"));
    args = [root, ...keep.flatMap((release) => ["--keep", release]), ...(firstOnly ? ["--without-previous"] : [])];
  } catch (error) {
    return { done: false, said: `${root} couldn't be read to tell which releases an open run may be using (${(error as Error).message}), so no release was pruned; ${later}` };
  }
  const prune = Bun.which("astra-release-prune", { PATH: process.env.PATH ?? "" });
  if (!prune) return { done: false, said: `astra-release-prune isn't on PATH (git-hooks' bun run promote installs it), so no release was pruned; ${later}` };
  let pruned: { code: number; out: string; err: string };
  try {
    pruned = await spawn([prune, ...args], root);
  } catch (error) {
    return { done: false, said: `astra-release-prune couldn't be started (${(error as Error).message}), so no release was pruned; ${later}` };
  }
  if (pruned.code === 0) return { done: true, said: pruned.out };
  return { done: false, said: `astra-release-prune exited ${pruned.code}, so what it could remove may not all be removed; ${later}. It said: ${[pruned.err, pruned.out].filter(Boolean).join("\n")}` };
}

export async function promote(spec: Spec, options: Options = {}): Promise<Answer> {
  const home = options.home ?? homedir();
  const source = options.source ?? spec.source;
  const account = options.account ?? accountHome();
  const lib = join(home, ".local/lib"),
    bin = join(home, ".local/bin");
  const root = join(lib, spec.packageName);
  if (await run(["git", "status", "--porcelain", "--untracked-files=all"], source)) throw Error("Commit this package's intended changes before promotion");
  const revision = await run(["git", "rev-parse", "HEAD"], source);
  const layout = spec.releases ? releasesLayout(root, bin) : null;
  const current = join(root, "current");
  if (!spec.releases && isLink(current))
    throw Error(
      `${root} is an install of releases, with a current link, and this spec installs in place, which would replace every release in it, so nothing was promoted. Promote it with a spec that sets releases.`,
    );
  const target = spec.releases ? join(root, "releases", revision) : root;
  const reused = spec.releases !== undefined && trimmedText(join(target, ".installed-revision")) === revision;
  if (spec.releases && !reused && present(target)) {
    const naming = (["current", "previous"] as const).filter((link) => isLink(join(root, link)) && canonical(join(root, link)) === canonical(target));
    throw Error(
      `${target} is there, but its .installed-revision doesn't name ${revision}: a build that stopped left it, or it's damaged. It may still be read, so nothing was promoted or removed. ` +
        (naming.length
          ? `${naming.join(" and ")} names it: point ${naming.length > 1 ? "them" : "it"} at a release that serves and remove ${target} once nothing reads it, or, if no other release is installed, remove ${root} with the component's launchers in ${bin}, so the next promote installs afresh, as a host's first, which asks no gate.`
          : `Remove it once nothing reads it, then promote again.`),
    );
  }
  const rehearsal = isRehearsal(home, account);
  const repository = markerRepository(source, rehearsal);
  const marker = repository ? markerPath(source) : null;
  const before = predecessor(spec.releases ? current : root, revision);
  const launchers = Object.keys(spec.commands).map((name) => join(bin, name));
  const gate = rehearsal
    ? "a rehearsal, from another home than the account's: no gate is asked"
    : askGate({ home, component: spec.component, revision, live: [root, ...launchers] });
  mkdirSync(lib, { recursive: true });
  let stage: string | null = null,
    began: string | null = null,
    selected = false;
  const temporaries = new Map<string, string>();
  const links: string[] = [];
  try {
    if (!spec.releases) stage = mkdtempSync(join(lib, `.${spec.packageName}-install-`));
    else if (!reused) {
      began = layout === "none" ? root : target;
      mkdirSync(target, { recursive: true });
    }
    const built = stage ?? target;
    const answersHelp = async (release: string, shebang: boolean) => {
      for (const entry of Object.values(spec.commands)) {
        console.error(`Checking that ${entry} answers --help in ${release}, before the switch.`);
        await run([...(shebang ? [] : [process.execPath, ...BUN_ALONE]), join(release, entry), "--help"], release, { ...process.env, HOME: home }).catch((error: Error & { code?: string }) => {
          // Bun 1.4.4 throws from spawn, rather than returning an exit, when the file is missing (ENOENT) or not executable (EACCES).
          if (!error.code) throw error;
          throw Error(
            `${entry} couldn't be started for its --help check (${error.code})` +
              (shebang && (error.code === "EACCES" || error.code === "ENOEXEC") ? `: with interpreter "shebang" it runs by its own first line, so commit it executable, starting with #!` : "") +
              `. Nothing was switched.`,
          );
        });
      }
    };
    const context: Context = { home, source, revision, rehearsal, target, run };
    let prepared: Record<string, unknown> = {};
    let shebang = spec.interpreter === "shebang";
    if (!reused) {
      const archive = join(built, "source.tar");
      await run(["git", "archive", "--format=tar", "-o", archive, revision], source);
      await run(["tar", "-xf", archive, "-C", built], source);
      rmSync(archive);
      const environment = installEnvironment(rehearsal, account);
      const install = (...flags: string[]) => run([process.execPath, "install", "--frozen-lockfile", "--backend=copyfile", ...flags], built, environment);
      await install("--production");
      prepared = (await spec.prepare?.({ ...context, stage: built, install })) ?? {};
      shebang = spec.interpreter === "shebang";
      await answersHelp(built, shebang);
      stamp(built, revision, before);
    } else if (!(isLink(current) && canonical(current) === canonical(target)))
      await answersHelp(built, shebang).catch((error: Error) => {
        throw Error(
          `${target} is the release already built for ${revision}, and it no longer answers the --help check, so nothing was switched. Remove it once nothing reads it, then promote again, which builds it afresh. ` +
            `What the check met: ${error.message.replace(/ Nothing was switched\.$/, "")}`,
        );
      });

    const files: { to: string; write: (temporary: string) => void }[] = [
      ...Object.entries(spec.commands).map(([name, entry]) => ({
        to: join(bin, name),
        write: (temporary: string) =>
          writeFileSync(temporary, `#!/bin/sh\nset -eu\nexec ${shebang ? "" : `${[process.execPath, ...BUN_ALONE].map(quote).join(" ")} `}${quote(join(target, entry))} "$@"\n`, { mode: 0o755 }),
      })),
      ...(spec.place ?? []).map(({ from, to }) => ({ to: join(home, to), write: (temporary: string) => copyFileSync(join(built, from), temporary) })),
    ];
    for (const file of files) {
      mkdirSync(dirname(file.to), { recursive: true });
      const temporary = join(dirname(file.to), `.${basename(file.to)}-${crypto.randomUUID()}`);
      temporaries.set(temporary, file.to);
      file.write(temporary);
    }
    let replaced: string | null = null;
    if (stage) await replaceDirectory(stage, root);
    else {
      const was = layout === "releases" ? realpathSync(current) : null;
      if (!was || canonical(was) !== canonical(target)) {
        const moves: [string, string][] = [];
        for (const [link, to] of [...(was ? [[join(root, "previous"), was]] : []), [current, target]] as [string, string][]) {
          const temporary = join(root, `.${basename(link)}-${crypto.randomUUID()}`);
          links.push(temporary);
          symlinkSync(to, temporary);
          moves.push([temporary, link]);
        }
        if (reused) writeSwitch(target, before);
        rmSync(join(target, ".replaced"), { force: true });
        for (const [temporary, link] of moves)
          try {
            renameSync(temporary, link);
          } catch (error) {
            throw Error(
              `The switch of ${link} to ${link === current ? target : was} failed (${(error as Error).message}), so nothing was switched` +
                (link === current && was ? `: current still names ${was}, which previous now names too.` : "."),
            );
          }
        replaced = was;
      }
    }
    selected = true;

    const parts: string[] = [];
    let unstamped = "";
    if (replaced)
      try {
        writeWhole(join(replaced, ".replaced"), new Date().toISOString() + "\n");
      } catch (error) {
        unstamped = `${replaced}'s .replaced couldn't be written (${(error as Error).message}), so it holds what it held before, if anything, and an open run may not keep it. `;
      }
    let unplaced = "";
    for (const [temporary, to] of temporaries)
      try {
        renameSync(temporary, to);
      } catch (error) {
        unplaced += `\n  ${to}: ${(error as Error).message}`;
      }
    if (unplaced)
      parts.push(
        `these files weren't put in place, so each still holds what was there before, and what watches a launcher among them won't restart onto this release by itself:${unplaced}\n  Clear what stopped each, then run the promote again, which puts them in place.`,
      );
    let recorded: string | null = null;
    if (repository && marker) {
      const marked = await recordMarker({ marker, repository, revision, before, cwd: source });
      if ("recorded" in marked) recorded = marked.recorded;
      else parts.push(marked.unfinished);
    }
    let after: Record<string, unknown> = {};
    try {
      after = (await spec.afterSwitch?.(context)) ?? {};
    } catch (error) {
      parts.push(error instanceof Error ? error.message : String(error));
    }
    const pruned = spec.releases ? await pruneReleases(root, spec.releases.openRuns) : null;
    if (parts.length) {
      const error = unfinished(revision, recorded !== null, parts);
      if (pruned) error.message += `\nPruning: ${unstamped}${pruned.said}`;
      throw error;
    }
    return {
      gate,
      marker: recorded,
      package: spec.packageName,
      revision,
      installed: target,
      commands: Object.keys(spec.commands),
      ...prepared,
      ...after,
      ...(pruned ? { prune: unstamped + pruned.said } : {}),
      adoption: spec.adoption,
    };
  } finally {
    removeLeftovers([...(stage ? [stage] : []), ...(began && !selected ? [began] : []), ...temporaries.keys(), ...links]);
  }
}

export function removeLeftovers(leftovers: Iterable<string>) {
  for (const leftover of leftovers)
    try {
      rmSync(leftover, { recursive: true, force: true });
    } catch (error) {
      console.error(`Left behind ${leftover}, to remove by hand: ${(error as Error).message}`);
    }
}

export async function main(packageName: string, promote: () => Promise<unknown>) {
  const lock = join(homedir(), `.local/lib/.${packageName}.promote.lock`);
  if (process.env.ASTRA_PROMOTE_LOCK !== lock) {
    mkdirSync(dirname(lock), { recursive: true });
    const held = Bun.spawnSync(["flock", lock, process.execPath, ...process.argv.slice(1)], {
      env: { ...process.env, ASTRA_PROMOTE_LOCK: lock },
      stdio: ["inherit", "inherit", "inherit"],
    });
    process.exit(held.exitCode ?? 1);
  }
  try {
    console.log(JSON.stringify(await promote(), null, 2));
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = error instanceof PromotedUnfinished ? 3 : 1;
  }
}
